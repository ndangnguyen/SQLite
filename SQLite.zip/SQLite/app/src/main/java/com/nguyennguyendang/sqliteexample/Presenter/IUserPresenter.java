package com.nguyennguyendang.sqliteexample.Presenter;

public interface IUserPresenter {
    void addUser(String id, String pass);
    void updatePassword(String id, String pass);
    void updateList();
    void deleteUser(String id);
    void getListUser();
}
