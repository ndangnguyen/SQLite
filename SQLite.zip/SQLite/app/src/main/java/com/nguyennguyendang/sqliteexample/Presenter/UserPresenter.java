package com.nguyennguyendang.sqliteexample.Presenter;

import android.content.Context;

import com.nguyennguyendang.sqliteexample.Model.Database;
import com.nguyennguyendang.sqliteexample.View.IUserView;

public class UserPresenter implements IUserPresenter {

    IUserView userView;
    Database database;

    public UserPresenter(IUserView userView) {
        this.userView = userView;
        database = new Database((Context)userView, "Nguyen", null, 1);
        database.createTable();
    }

    @Override
    public void addUser(String id, String pass) {
        database.addUser(id, pass);
    }

    @Override
    public void updatePassword(String id, String pass) {

    }

    @Override
    public void updateList() {
        userView.updateListView();
    }

    @Override
    public void deleteUser(String id) {

    }

    @Override
    public void getListUser() {
        userView.setListUser(database.getListUser());
    }
}
