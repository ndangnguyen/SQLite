package com.nguyennguyendang.sqliteexample.View;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.nguyennguyendang.sqliteexample.Model.User;
import com.nguyennguyendang.sqliteexample.Presenter.UserPresenter;
import com.nguyennguyendang.sqliteexample.R;
import com.nguyennguyendang.sqliteexample.Utils.CustomAdapter;

import java.util.ArrayList;

import static com.nguyennguyendang.sqliteexample.R.id.etID;

public class MainActivity extends AppCompatActivity implements IUserView{

    UserPresenter userPresenter;
    EditText etID, etPassword;
    Button btnSave, btnNewUser;
    ListView lvUser;
    CustomAdapter arrayAdapter;
    ArrayList<User> listUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        getView();
        setView();
        addListener();
    }

    private void init() {
        userPresenter = new UserPresenter(this);
    }

    private void getView() {
        etID = findViewById(R.id.etID);
        etPassword = findViewById(R.id.etPassword);
        btnSave = findViewById(R.id.btnSave);
        btnNewUser = findViewById(R.id.btnNewUser);
        lvUser = findViewById(R.id.lvUser);
        String currentMidletVersionString = "1.9.8";
        currentMidletVersionString = currentMidletVersionString.replaceAll(".","");
        Log.d("currentMidl", "currentMidletVersionString: " + currentMidletVersionString);
    }

    private void setView() {
        userPresenter.getListUser();
        arrayAdapter = new CustomAdapter(this,  R.layout.custom_item, listUser);
        lvUser.setAdapter(arrayAdapter);
    }

    private void addListener() {
        btnNewUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userPresenter.addUser(etID.getText().toString().trim(), etPassword.getText().toString().trim());
                userPresenter.getListUser();
                userPresenter.updateList();
            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    @Override
    public void setListUser(ArrayList<User> listUser) {
        this.listUser = listUser;
    }

    @Override
    public void updateListView() {
        arrayAdapter.notifyDataSetChanged();
    }
}
