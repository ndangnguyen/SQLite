package com.nguyennguyendang.sqliteexample.View;

import com.nguyennguyendang.sqliteexample.Model.User;

import java.util.ArrayList;

public interface IUserView {
    void setListUser(ArrayList<User> list);
    void updateListView();
}
