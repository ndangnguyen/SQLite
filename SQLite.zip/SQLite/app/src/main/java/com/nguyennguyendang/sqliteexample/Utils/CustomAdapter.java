package com.nguyennguyendang.sqliteexample.Utils;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.nguyennguyendang.sqliteexample.Model.User;
import com.nguyennguyendang.sqliteexample.R;

import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter<User> {

    LayoutInflater inflater;
    ArrayList<User> listUser;
    int resource;
    public CustomAdapter(Context context, int resource, ArrayList<User> objects) {
        super(context, resource, objects);
        inflater = LayoutInflater.from(context);
        listUser = objects;
        this.resource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = inflater.inflate(resource, parent, false);
            viewHolder.tvName = convertView.findViewById(R.id.tvName);
            viewHolder.tvPsss = convertView.findViewById(R.id.tvPass);
            viewHolder.ivAvatar = convertView.findViewById(R.id.ivAvatar);
            viewHolder.btnEdit = convertView.findViewById(R.id.btnEdit);
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.tvName.setText(listUser.get(position).getName());
        viewHolder.tvPsss.setText(listUser.get(position).getPass());
        return convertView;
    }

    private static class ViewHolder {
        TextView tvName;
        TextView tvPsss;
        ImageView ivAvatar;
        Button btnEdit;
    }
}
