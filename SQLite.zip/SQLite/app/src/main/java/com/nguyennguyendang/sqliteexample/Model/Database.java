package com.nguyennguyendang.sqliteexample.Model;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {
    public Database(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void queryData(String sql) {
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sql);
    }

    public Cursor getData(String sql) {
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql, null);
    }

    public void addUser(String id, String pass) {
        String sql = "INSERT INTO User VALUES(null,'"+ pass +"')";
        queryData(sql);
    }

    public void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS User3(id VARCHAR(20) PRIMARY KEY, pass VARCHAR(20))";
//        String sql = "CREATE TABLE User(id INTEGER PRIMARY KEY AUTOINCREMENT, pass VARCHAR(20))";
        queryData(sql);
        //sql = "INSERT INTO User VALUES('Nguyen','123')";
        //queryData(sql);
        sql = "INSERT INTO User VALUES('Tuyet','456')";
        queryData(sql);
        sql = "INSERT INTO User VALUES('Nguyen','678')";
        queryData(sql);
    }

    public ArrayList<User> getListUser() {
        ArrayList<User> list = new ArrayList<>();
        String sql = "SELECT * FROM User";
        Cursor cursor = getData(sql);
        while (cursor.moveToNext()) {
            String id = cursor.getString(0);
            String pass = cursor.getString(1);
            User newUser = new User(id, pass);
            list.add(newUser);
            cursor.moveToNext();
        }
        return list;
    }
}
